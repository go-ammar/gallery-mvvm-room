package com.example.galleryapplicatoin.ui.network

import com.example.galleryapplicatoin.ui.models.Images
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    /*
 All endpoints go in this interface
  */

    @GET("api")
    fun getImages(
        @Query("key") key: String,
        @Query("q") searchQuery: String,
        @Query("orientation") orientation : String): Call<Images>

}