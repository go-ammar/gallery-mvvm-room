package com.example.galleryapplicatoin.ui.adapters

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.galleryapplicatoin.R
import com.example.galleryapplicatoin.ui.models.Hit
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class BindingAdapter {

    companion object {

        @JvmStatic
        @BindingAdapter
            ("loadUrl")
        fun ImageView.loadImage(hit: Hit) {
            val iv = this
            MainScope().launch {
                Glide.with(context)
                    .load(hit.webformatURL)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .override(-1, -1)
                    .priority(Priority.HIGH)
                    .thumbnail(
                        Glide.with(context).load(R.raw.loading_gif)
                    )
                    .into(iv)
            }

        }

        @JvmStatic
        @BindingAdapter
            ("loadPic")
        fun ImageView.loadSingleImage(hit: Hit) {
            val iv = this
            MainScope().launch {
                Glide.with(context)
                    .load(hit.webformatURL)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .override(-1, -1)
                    .priority(Priority.HIGH)
                    .into(iv)
            }

        }

    }

}