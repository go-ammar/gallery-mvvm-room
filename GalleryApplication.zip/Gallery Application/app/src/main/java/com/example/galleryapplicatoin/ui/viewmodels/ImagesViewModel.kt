package com.example.galleryapplicatoin.ui.viewmodels

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.galleryapplicatoin.ui.models.Hit
import com.example.galleryapplicatoin.ui.models.Images
import com.example.galleryapplicatoin.ui.network.ApiService
import com.example.galleryapplicatoin.ui.network.RetrofitInstance
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ImagesViewModel : ViewModel() {
    var imagesLiveData: MutableLiveData<List<Hit>>? = null
    private val TAG = "ImagesViewModel"
    private var searchJob: Job? = null

    init {
        this.imagesLiveData = MutableLiveData()
    }

    fun getImagesListObserver(): MutableLiveData<List<Hit>>? {
        Log.d(TAG, "getImagesListObserver: ")
        return imagesLiveData
    }


    fun searchDebounced(searchText: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {

            delay(1000)

            val apiService = RetrofitInstance.getRetrofitClient().create(ApiService::class.java)
            //Get string for searchParameterName from search bar

            val call: Call<Images> =
                apiService.getImages("20407077-ea8f89160b9cdfff4a6672d3d", searchText, "vertical")

            call.enqueue(object : Callback<Images> {
                override fun onResponse(call: Call<Images>, response: Response<Images>) {
                    imagesLiveData?.postValue(response.body()?.hits)
                }

                override fun onFailure(call: Call<Images>, t: Throwable) {
                }

            })

        }
    }

}