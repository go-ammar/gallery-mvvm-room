package com.example.galleryapplicatoin.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.core.view.doOnPreDraw
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import androidx.transition.TransitionInflater
import com.example.galleryapplicatoin.R
import com.example.galleryapplicatoin.databinding.FragmentHomeBinding
import com.example.galleryapplicatoin.ui.adapters.ImageAdapter
import com.example.galleryapplicatoin.ui.models.Hit
import com.example.galleryapplicatoin.ui.viewmodels.ImagesViewModel
import java.util.concurrent.TimeUnit


class HomeFragment : Fragment() {
    lateinit var binding: FragmentHomeBinding

    lateinit var imagesAdapter: ImageAdapter
    lateinit var imagesModelList: List<Hit>
    lateinit var imagesViewModel: ImagesViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false)

        sharedElementEnterTransition =
            TransitionInflater.from(context).inflateTransition(android.R.transition.move)
        postponeEnterTransition(250, TimeUnit.MILLISECONDS)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        imagesViewModel = ViewModelProvider(this).get(ImagesViewModel::class.java)

        imagesModelList = emptyList()
        imagesAdapter =
            ImageAdapter(context = requireContext(), imageList = imagesModelList, listener)

        binding.recyclerView.adapter = imagesAdapter

        binding.darkMode.setOnClickListener {
            if (binding.darkMode.isChecked)
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }


        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextChange(s: String): Boolean {
                if (binding.searchView.hasFocus()) {
                    imagesModelList = emptyList()
                    imagesViewModel.searchDebounced(
                        binding.searchView.query.toString().replace(" ", "+")
                    )
                }
                return true
            }
            override fun onQueryTextSubmit(s: String): Boolean {
                return true
            }
        })

        imagesViewModel.getImagesListObserver()?.observe(viewLifecycleOwner, {
            imagesModelList = emptyList()
            if (it.isEmpty()) {
                Toast.makeText(context, "No Images found", Toast.LENGTH_SHORT).show()
            }
            imagesModelList = it
            imagesAdapter.setImageList(it)
            binding.recyclerView.scheduleLayoutAnimation()
        })

    }

    private var listener: ImageAdapter.OnClickListener =
        ImageAdapter.OnClickListener { hit, image ->
            val action = HomeFragmentDirections.actionHomeFragmentToImageFragment(hit)
            val extras = FragmentNavigatorExtras(
                image to hit.webformatURL
            )
            findNavController().navigate(action, extras)
        }
}