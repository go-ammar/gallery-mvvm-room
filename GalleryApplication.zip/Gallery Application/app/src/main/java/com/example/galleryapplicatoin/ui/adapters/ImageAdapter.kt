package com.example.galleryapplicatoin.ui.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.request.target.Target.SIZE_ORIGINAL
import com.example.galleryapplicatoin.R
import com.example.galleryapplicatoin.databinding.ItemImagesBinding
import com.example.galleryapplicatoin.ui.models.Hit

class ImageAdapter(var context: Context, private var imageList: List<Hit>, private val onClickListener: OnClickListener) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(context),
                R.layout.item_images, parent, false
            )
        )
    }

    fun setImageList(imageList: List<Hit>) {
        this.imageList = imageList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val hit = imageList[position]
        ((holder) as ViewHolder).setBinding(hit)
        (holder).binding.image.setOnClickListener {
            onClickListener.onClick(hit, it as ImageView)
        }
    }

    override fun getItemCount(): Int {
        return imageList.size
    }

    class OnClickListener(val clickListener: (Hit, ImageView) -> Unit) {
        fun onClick(
            hit: Hit,
            view: ImageView
        ) = clickListener(hit, view)
    }

    class ViewHolder(var binding: ItemImagesBinding) : RecyclerView.ViewHolder(
        binding.root
    ) {
        fun setBinding(hit: Hit) {
            binding.hit = hit
        }
    }

}